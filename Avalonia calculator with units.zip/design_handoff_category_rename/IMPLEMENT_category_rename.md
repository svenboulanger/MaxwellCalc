# Implement: rename output-unit category names (command palette → Units → Output units)

## What's missing

In the HTML prototype, each **category header** in the Output-units list (LENGTH, MASS, TIME, …)
is renameable: a pencil ✎ next to the header opens an inline field where you type a new name,
press **Save** (or Enter), and the header re-labels. A renamed header shows a small `•` marker and
a **Reset** button that restores the built-in name. This never made it into the Avalonia app —
the C# header is a plain, read-only label.

This document is a complete spec + code to add that feature to `MaxwellCalc.Notebook`. **No changes
to `MaxwellCalc.Core` are required.**

### Reference: how it looks in the prototype

Output-units list — note the ✎ pencil after each header, and the `•` on the already-renamed
"DISTANCES" group (renamed from *Length*):

![Output units list with rename pencils](prototype_output_units.png)

Inline editing state — the header becomes a text field with **Reset** (only shown once renamed)
and **Save**:

![Header inline edit state](prototype_rename_editing.png)

---

## Where categories live (important — read first)

- The display label for each output-unit group comes from **`IWorkspace.UnitCategories`**
  (`Dictionary<Unit, string>`, keyed by the **base unit**). `UnitHelper.RegisterCommonUnits`
  seeds it with lower-case names (`"length"`, `"mass"`, `"time"`, …); the panel upper-cases them
  for display. Output units whose base unit has **no** category entry fall back to the base unit's
  own string (e.g. `kg`, `m·s⁻¹`).
- Renaming a category = **writing `workspace.UnitCategories[baseUnit] = newName`**. Resetting =
  restoring the seeded value (or removing the entry when there was none).
- **Persistence is already wired.** `WorkspaceJsonConverter` serializes/deserializes
  `unit_categories`, and `SettingsViewModel.Persist()` (called from `ShellWindow` on window close)
  writes `workspace.json`. Like the existing overlay add/remove-unit flows, category edits mutate
  Core directly and are saved at shutdown — **no new persistence code needed**.
- `UnitCategories` is a plain `Dictionary`, **not** an observable dictionary, so mutating it does
  **not** fire the panel's auto-rebuild. After a rename/reset you must re-flatten the rows yourself
  (the code below does this).

All edits are in three files:

1. `ViewModels/Overlay/PanelItems.cs` — extend `OutputHeaderRow`.
2. `ViewModels/Overlay/OutputUnitsPanelViewModel.cs` — edit state, commands, stable ordering.
3. `Views/CommandPaletteView.axaml` (+ `.axaml.cs`) — the header template + autofocus.

---

## 1) `PanelItems.cs` — extend `OutputHeaderRow`

Replace the existing `OutputHeaderRow` record with:

```csharp
/// <summary>
/// A section header row in the Output-units list: the physical-quantity label (Length, Mass, …).
/// Carries the base <see cref="Unit"/> it maps to so the header can be renamed (writing back to
/// <c>workspace.UnitCategories</c>). <see cref="IsEditing"/> is part of the record's value identity,
/// so toggling it makes the CollectionReconciler swap the realized container — which re-runs the
/// template (and the rename field's Loaded autofocus).
/// </summary>
public sealed record OutputHeaderRow : OutputRow
{
    /// <summary>Gets the physical-quantity label for the group (display, upper-cased).</summary>
    public required string Label { get; init; }

    /// <summary>Gets the base unit this category is keyed by in <c>UnitCategories</c>.</summary>
    public required Unit CategoryKey { get; init; }

    /// <summary>Gets whether this category has been renamed from its built-in default (shows the • marker + Reset).</summary>
    public bool IsRenamed { get; init; }

    /// <summary>Gets whether this header is currently in inline-edit mode.</summary>
    public bool IsEditing { get; init; }
}
```

`Unit` is already imported (`using MaxwellCalc.Core.Units;`).

---

## 2) `OutputUnitsPanelViewModel.cs`

Add edit state + commands, make row-flattening reusable, and make group **ordering stable**
(so renaming doesn't re-sort the groups). Concretely:

### a) Add fields (next to `NewUnit` / `NewDefinition`)

```csharp
/// <summary>The base unit of the category currently being renamed, or null when not editing.</summary>
[ObservableProperty]
private Unit? _editingCategoryKey;

/// <summary>The text bound to the inline rename field.</summary>
[ObservableProperty]
private string _categoryDraft = string.Empty;
```

### b) Built-in category defaults (for Reset + stable ordering)

Both domains register identical categories via `RegisterCommonUnits`, so a one-off snapshot from a
fresh workspace gives us the built-in defaults without touching Core:

```csharp
// Built-in category names, captured once from a pristine workspace. Used to (a) order groups by a
// STABLE key so a rename doesn't re-sort the list, and (b) restore the default on Reset.
private static readonly Dictionary<Unit, string> DefaultCategories =
    WorkspaceState.CreateDefaultWorkspace().UnitCategories;

/// <summary>The built-in (pre-rename) label for a base unit, upper-cased; base-unit string as fallback.</summary>
private static string DefaultCategoryLabel(Unit baseUnit)
{
    if (DefaultCategories.TryGetValue(baseUnit, out var category))
        return category.ToUpperInvariant();
    string key = baseUnit.ToString();
    return key.Length == 0 ? "Dimensionless" : key;
}
```

(Add `using MaxwellCalc.Notebook.ViewModels;` for `WorkspaceState` if not already present, or fully
qualify it.)

### c) Order groups by the *default* label, not the live one

Replace the group comparison in `Compare` so groups keep a fixed position even after a rename:

```csharp
protected override int Compare(OutputUnitItem a, OutputUnitItem b)
{
    // Order by the STABLE default category so renaming a group doesn't move it in the list.
    int byGroup = StringComparer.OrdinalIgnoreCase.Compare(
        DefaultCategoryLabel(a.Definition.Unit),
        DefaultCategoryLabel(b.Definition.Unit));
    if (byGroup != 0)
        return byGroup;
    return StringComparer.OrdinalIgnoreCase.Compare(a.Label, b.Label);
}
```

### d) Build header rows with rename state, and make it re-callable

Replace `OnItemsChanged` with a thin override that calls a reusable `RebuildRows()`:

```csharp
protected override void OnItemsChanged() => RebuildRows();

/// <summary>
/// Flattens the (default-category-then-label sorted) items into header + unit rows, tagging each
/// header with its rename/edit state, then reconciles in place. Re-called after a rename/reset since
/// UnitCategories isn't observable.
/// </summary>
private void RebuildRows()
{
    var rows = new List<OutputRow>(Items.Count);
    // Group by the base unit itself so each header maps 1:1 to a UnitCategories key.
    foreach (var group in Items.GroupBy(item => item.Definition.Unit))
    {
        Unit key = group.Key;
        rows.Add(new OutputHeaderRow
        {
            Label = CategoryLabel(key),
            CategoryKey = key,
            IsRenamed = CategoryLabel(key) != DefaultCategoryLabel(key),
            IsEditing = EditingCategoryKey is { } editing && editing.Equals(key),
        });
        foreach (var item in group)
            rows.Add(item);
    }
    CollectionReconciler.Reconcile(Rows, rows);
}
```

> Note: grouping now keys on `item.Definition.Unit` (the base unit) instead of the label string, so
> the header always has the exact `UnitCategories` key to write back to. `CategoryLabel` (the
> existing private helper that reads the live `UnitCategories`) stays as-is and is reused here.

### e) The commands

```csharp
/// <summary>Enters inline-edit mode for a category header (the ✎ pencil).</summary>
[RelayCommand]
private void BeginRename(OutputHeaderRow row)
{
    EditingCategoryKey = row.CategoryKey;
    CategoryDraft = row.Label;
    RebuildRows();
}

/// <summary>Commits the inline rename (Save button / Enter).</summary>
[RelayCommand]
private void CommitRename()
{
    if (EditingCategoryKey is not { } key)
        return;

    var workspace = WorkspaceState.Workspace;
    string name = CategoryDraft.Trim();
    if (workspace is not null)
    {
        // Empty, or equal to the built-in default, clears the override; otherwise store the new name.
        if (name.Length == 0 ||
            string.Equals(name, DefaultCategoryLabel(key), StringComparison.OrdinalIgnoreCase))
        {
            ResetCategoryEntry(workspace, key);
        }
        else
        {
            workspace.UnitCategories[key] = name;
        }
    }

    EditingCategoryKey = null;
    CategoryDraft = string.Empty;
    RebuildRows();
}

/// <summary>Cancels inline editing without saving (Esc).</summary>
[RelayCommand]
private void CancelRename()
{
    EditingCategoryKey = null;
    CategoryDraft = string.Empty;
    RebuildRows();
}

/// <summary>Resets a category to its built-in default (the Reset button).</summary>
[RelayCommand]
private void ResetCategory(OutputHeaderRow row)
{
    var workspace = WorkspaceState.Workspace;
    if (workspace is not null)
        ResetCategoryEntry(workspace, row.CategoryKey);

    EditingCategoryKey = null;
    CategoryDraft = string.Empty;
    RebuildRows();
}

// Restore the seeded default (or remove the entry entirely when the unit had no built-in category).
private static void ResetCategoryEntry(IWorkspace workspace, Unit key)
{
    if (DefaultCategories.TryGetValue(key, out var seeded))
        workspace.UnitCategories[key] = seeded;
    else
        workspace.UnitCategories.Remove(key);
}
```

Required `using`s (most already present): `System.Collections.Generic`, `System.Linq`,
`MaxwellCalc.Core.Units`, `MaxwellCalc.Core.Workspaces`, `CommunityToolkit.Mvvm.Input`,
`CommunityToolkit.Mvvm.ComponentModel`.

---

## 3) `CommandPaletteView.axaml` — the header template

Replace the current read-only header template:

```xml
<DataTemplate DataType="overlay:OutputHeaderRow">
    <TextBlock Classes="sectionLabel" Text="{Binding Label}" />
</DataTemplate>
```

with a two-mode template (display / editing). It reuses the existing `sectionLabel`, `addField` and
`add` styles; add the two small styles below to `UserControl.Styles` first.

### New styles (add near the other `Button` styles)

```xml
<!-- Ghost icon button for the ✎ rename pencil in a category header. -->
<Style Selector="Button.headerIcon">
    <Setter Property="Background" Value="Transparent" />
    <Setter Property="BorderThickness" Value="0" />
    <Setter Property="Padding" Value="3" />
    <Setter Property="CornerRadius" Value="5" />
    <Setter Property="VerticalAlignment" Value="Center" />
    <Setter Property="Foreground" Value="{DynamicResource FaintBrush}" />
</Style>
<Style Selector="Button.headerIcon:pointerover">
    <Setter Property="Foreground" Value="{DynamicResource InkBrush}" />
</Style>

<!-- Bordered "Reset" button shown while editing a renamed category. -->
<Style Selector="Button.resetCat">
    <Setter Property="Background" Value="Transparent" />
    <Setter Property="BorderBrush" Value="{DynamicResource ChipBorderBrush}" />
    <Setter Property="BorderThickness" Value="1" />
    <Setter Property="CornerRadius" Value="{DynamicResource InputCornerRadius}" />
    <Setter Property="Padding" Value="10,5" />
    <Setter Property="FontFamily" Value="{DynamicResource UiFontFamily}" />
    <Setter Property="FontSize" Value="11" />
    <Setter Property="FontWeight" Value="SemiBold" />
    <Setter Property="Foreground" Value="{DynamicResource MutBrush}" />
    <Setter Property="VerticalAlignment" Value="Center" />
</Style>
```

### The template

```xml
<DataTemplate DataType="overlay:OutputHeaderRow">
    <Panel Margin="0,14,0,7">

        <!-- DISPLAY MODE -->
        <Grid IsVisible="{Binding !IsEditing}"
              ColumnDefinitions="Auto,Auto,Auto" ColumnSpacing="7">
            <TextBlock Grid.Column="0" Classes="sectionLabel" Margin="0"
                       VerticalAlignment="Center" Text="{Binding Label}" />
            <!-- • marker: this category has been renamed from its default. -->
            <TextBlock Grid.Column="1" Text="•" VerticalAlignment="Center"
                       Foreground="{DynamicResource FaintBrush}"
                       IsVisible="{Binding IsRenamed}"
                       ToolTip.Tip="Renamed from the built-in name" />
            <Button Grid.Column="2" Classes="headerIcon"
                    ToolTip.Tip="Rename category"
                    Command="{Binding ((vm:CommandPaletteViewModel)DataContext).OutputUnits.BeginRenameCommand, RelativeSource={RelativeSource AncestorType=UserControl}}"
                    CommandParameter="{Binding}">
                <materialIcons:MaterialIcon Kind="Pencil" Width="13" Height="13" />
            </Button>
        </Grid>

        <!-- EDIT MODE -->
        <Grid IsVisible="{Binding IsEditing}"
              ColumnDefinitions="*,Auto,Auto" ColumnSpacing="7">
            <TextBox Grid.Column="0" Classes="addField"
                     Loaded="OnRenameFieldLoaded"
                     Text="{Binding ((vm:CommandPaletteViewModel)DataContext).OutputUnits.CategoryDraft, RelativeSource={RelativeSource AncestorType=UserControl}, Mode=TwoWay}">
                <TextBox.KeyBindings>
                    <KeyBinding Gesture="Enter"
                                Command="{Binding ((vm:CommandPaletteViewModel)DataContext).OutputUnits.CommitRenameCommand, RelativeSource={RelativeSource AncestorType=UserControl}}" />
                    <KeyBinding Gesture="Escape"
                                Command="{Binding ((vm:CommandPaletteViewModel)DataContext).OutputUnits.CancelRenameCommand, RelativeSource={RelativeSource AncestorType=UserControl}}" />
                </TextBox.KeyBindings>
            </TextBox>
            <Button Grid.Column="1" Classes="resetCat" Content="Reset"
                    IsVisible="{Binding IsRenamed}"
                    Command="{Binding ((vm:CommandPaletteViewModel)DataContext).OutputUnits.ResetCategoryCommand, RelativeSource={RelativeSource AncestorType=UserControl}}"
                    CommandParameter="{Binding}" />
            <Button Grid.Column="2" Classes="add" Content="Save"
                    Command="{Binding ((vm:CommandPaletteViewModel)DataContext).OutputUnits.CommitRenameCommand, RelativeSource={RelativeSource AncestorType=UserControl}}" />
        </Grid>
    </Panel>
</DataTemplate>
```

`Kind="Pencil"` is a valid `Material.Icons` glyph (matches the existing `Kind="Close"` usage).

### Autofocus the rename field (`CommandPaletteView.axaml.cs`)

Because `IsEditing` is part of `OutputHeaderRow`'s value identity, the reconciler replaces the
header's container when editing begins, so the edit `TextBox` is freshly created and its `Loaded`
fires. Focus + select-all there:

```csharp
using Avalonia.Controls;
using Avalonia.Interactivity;
using MaxwellCalc.Notebook.ViewModels.Overlay;

// inside the CommandPaletteView class:
private void OnRenameFieldLoaded(object? sender, RoutedEventArgs e)
{
    if (sender is TextBox tb && tb.DataContext is OutputHeaderRow { IsEditing: true })
    {
        tb.Focus();
        tb.SelectAll();
    }
}
```

---

## Behavior spec (match the prototype)

- **Pencil ✎** on a header → enters edit mode; the field is autofocused with the current name selected.
- **Enter** or **Save** → commits. Empty text, or text equal to the built-in default, clears the
  override (reverts to default); anything else stores the new name.
- **Esc** → cancels, no change.
- **Reset** → shown only when the category differs from its built-in default; restores the default
  (removing the `UnitCategories` entry when the unit had no built-in category).
- A renamed header shows a faint **•** marker in display mode.
- Group **order is fixed** (by the built-in default name) — renaming never reshuffles the list.
- Changes persist automatically to `workspace.json` on app close (same as the existing add/remove
  unit flows). Renamed names round-trip via `unit_categories` and re-appear on next launch.
- Renaming is **display-only** — it does not affect unit resolution or auto-output-unit selection.

## Test checklist

- Open ⌘K → **Units** → **Output units**. Every header has a pencil.
- Rename *Length* → *Distances*: header re-labels, `•` appears, order unchanged.
- Reset *Distances*: reverts to *LENGTH*, `•` and Reset disappear.
- Rename a group whose base unit had **no** default category (e.g. a composite like the Speed
  group), then Reset: the entry is removed and it falls back to the base-unit string label.
- Close and relaunch the app: renamed categories persist.
- Add a `SheetEvaluatorTests`-style or workspace round-trip test asserting
  `UnitCategories[baseUnit]` survives `WorkspaceJsonConverter` serialize→deserialize (the
  converter already handles `unit_categories`; confirm your rename is picked up).
